export const BASE_URL = 'https://connectify-a1zv.onrender.com/'
  //'http://localhost:5000'
