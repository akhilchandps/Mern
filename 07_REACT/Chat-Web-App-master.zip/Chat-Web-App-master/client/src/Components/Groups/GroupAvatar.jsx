import { Avatar, AvatarGroup } from '@mui/material'
import React from 'react'
import { useSelector } from 'react-redux'

function GroupAvatar({width,height,isOnline,pfp,uName,noBadge,fs}) {
  const lightTheme = useSelector(state=>state.themeKey)
  return (
    <>
          
    </>
  )
}

export default GroupAvatar